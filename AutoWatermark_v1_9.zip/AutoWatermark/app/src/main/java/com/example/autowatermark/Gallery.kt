package com.example.autowatermark

import android.graphics.Bitmap
import android.net.Uri
import android.provider.MediaStore
import android.util.Size
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private class GImg(val uri: Uri, val bucket: String)

/** 应用内相册选择器：按相册筛选，缩略图网格，点选多张。 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GalleryPicker(onCancel: () -> Unit, onDone: (List<Uri>) -> Unit) {
    val ctx = LocalContext.current
    var all by remember { mutableStateOf<List<GImg>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var album by remember { mutableStateOf("") }          // 空 = 全部
    var sel by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var expanded by remember { mutableStateOf(false) }

    BackHandler(onBack = onCancel)
    LaunchedEffect(Unit) {
        all = withContext(Dispatchers.IO) {
            val out = ArrayList<GImg>()
            runCatching {
                val ext = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                ctx.contentResolver.query(ext,
                    arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.BUCKET_DISPLAY_NAME),
                    null, null, "${MediaStore.Images.Media._ID} DESC")?.use {
                    while (it.moveToNext())
                        out.add(GImg(android.content.ContentUris.withAppendedId(ext, it.getLong(0)), it.getString(1) ?: "其他"))
                }
            }
            out
        }
        loading = false
    }

    val buckets = remember(all) { all.groupBy { it.bucket }.entries.sortedByDescending { it.value.size }.map { it.key } }
    val shown = remember(all, album) { if (album.isEmpty()) all else all.filter { it.bucket == album } }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onCancel) { Text("← 返回") }
            Text(if (sel.isEmpty()) "选择照片" else "已选 ${sel.size} 张", Modifier.weight(1f),
                style = MaterialTheme.typography.titleMedium)
            Button({ onDone(sel) }, enabled = sel.isNotEmpty()) { Text("确定") }
        }
        ExposedDropdownMenuBox(expanded, { expanded = it }, Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) {
            OutlinedTextField(
                value = if (album.isEmpty()) "全部照片" else album, onValueChange = {}, readOnly = true,
                modifier = Modifier.menuAnchor().fillMaxWidth(), label = { Text("相册") },
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) })
            ExposedDropdownMenu(expanded, { expanded = false }) {
                DropdownMenuItem(text = { Text("全部照片") }, onClick = { album = ""; expanded = false })
                buckets.forEach { b ->
                    DropdownMenuItem(text = { Text(b) }, onClick = { album = b; expanded = false })
                }
            }
        }
        if (!loading && shown.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("没有找到照片") }
        } else {
            LazyVerticalGrid(GridCells.Fixed(3), Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.spacedBy(2.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                items(shown, key = { it.uri.toString() }) { g ->
                    val idx = sel.indexOf(g.uri)
                    Box(Modifier.aspectRatio(1f).clickable {
                        sel = if (idx >= 0) sel - g.uri else sel + g.uri
                    }) {
                        Thumb(g.uri)
                        if (idx >= 0) {
                            Box(Modifier.fillMaxSize().background(Color(0x553F51B5)))
                            Text("${idx + 1}", Modifier.align(Alignment.TopEnd).padding(4.dp)
                                .background(MaterialTheme.colorScheme.primary, CircleShape)
                                .padding(horizontal = 7.dp, vertical = 2.dp),
                                color = Color.White, style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Thumb(uri: Uri) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) {
            runCatching { ctx.contentResolver.loadThumbnail(uri, Size(256, 256), null) }.getOrNull()
        }
    }
    val b = bmp
    if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
    else Box(Modifier.fillMaxSize().background(Color(0xFFE0E0E0)))
}
