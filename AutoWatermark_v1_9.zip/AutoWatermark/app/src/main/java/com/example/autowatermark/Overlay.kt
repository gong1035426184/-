package com.example.autowatermark

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView

/** 监听状态悬浮窗：绿=监听中，橙=处理中/警告，红=已关闭（2.5 秒后自动消失）。可拖动。 */
object Overlay {
    val GREEN = 0xE62E7D32.toInt()
    val ORANGE = 0xE6EF6C00.toInt()
    val RED = 0xE6C62828.toInt()

    private val h = Handler(Looper.getMainLooper())
    private var view: TextView? = null
    private var wm: WindowManager? = null
    private val hideRun = Runnable { removeNow() }

    fun show(c: Context, text: String, color: Int, autoHideMs: Long = 0L) {
        h.post {
            val app = c.applicationContext
            if (Store.str(app, "float", "1") != "1" || !Settings.canDrawOverlays(app)) { removeNow(); return@post }
            h.removeCallbacks(hideRun)
            val tv = view ?: create(app)
            tv.text = text
            tv.background = GradientDrawable().apply {
                setColor(color); cornerRadius = 100f * tv.resources.displayMetrics.density
            }
            if (autoHideMs > 0) h.postDelayed(hideRun, autoHideMs)
        }
    }

    fun hide() { h.post { h.removeCallbacks(hideRun); removeNow() } }

    private fun removeNow() {
        view?.let { v -> runCatching { wm?.removeView(v) } }
        view = null; wm = null
    }

    private fun create(app: Context): TextView {
        val w = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val d = app.resources.displayMetrics.density
        val tv = TextView(app).apply {
            setTextColor(Color.WHITE); textSize = 12f
            setPadding((12 * d).toInt(), (6 * d).toInt(), (12 * d).toInt(), (6 * d).toInt())
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = (12 * d).toInt(); y = (96 * d).toInt() }
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt()
                    runCatching { w.updateViewLayout(tv, lp) }
                }
            }
            true
        }
        w.addView(tv, lp)
        wm = w; view = tv
        return tv
    }
}
