package com.example.autowatermark

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.widget.Toast
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface { App() } } }
    }
}

private fun parseHex(t: String): Int? =
    runCatching { android.graphics.Color.parseColor("#" + t.trim().removePrefix("#")) }.getOrNull()
private fun hex(c: Int) = "%06X".format(c and 0xFFFFFF)

private fun hasMedia(c: Context) = ContextCompat.checkSelfPermission(c,
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES
    else Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
private fun hasNotif(c: Context) = Build.VERSION.SDK_INT < 33 ||
    ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
private fun allFiles() = Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()
private fun noBatteryLimit(c: Context) =
    (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(c.packageName)

/** 依次尝试多个 Intent，第一个能打开的为准 */
private fun open(c: Context, vararg intents: Intent) {
    for (i in intents) if (runCatching { c.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }.isSuccess) return
}

@Composable
fun PermRow(title: String, ok: Boolean?, btn: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title)
            if (ok != null) Text(if (ok) "已开启" else "未开启", style = MaterialTheme.typography.bodySmall,
                color = if (ok) Color(0xFF2E7D32) else Color(0xFFC62828))
        }
        if (ok == true) OutlinedButton(onClick) { Text("设置") } else Button(onClick) { Text(btn) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val ctx = LocalContext.current
    var styles by remember { mutableStateOf(Store.all(ctx)) }
    var active by remember { mutableStateOf(Store.str(ctx, "active", "mi_leica")) }
    var on by remember { mutableStateOf(Store.str(ctx, "on", "0") == "1") }
    var device by remember { mutableStateOf(Store.str(ctx, "device", "")) }
    var watch by remember { mutableStateOf(Store.str(ctx, "watch", "DCIM/Camera")) }
    var editing by remember { mutableStateOf<WmStyle?>(null) }
    var tick by remember { mutableStateOf(0) }      // 从系统设置页回来时刷新权限状态
    var pending by remember { mutableStateOf(false) }
    var keep by remember { mutableStateOf(Store.str(ctx, "keep", "1") == "1") }
    var floatOn by remember { mutableStateOf(Store.str(ctx, "float", "1") == "1") }

    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        lifecycle.addObserver(o); onDispose { lifecycle.removeObserver(o) }
    }

    fun startListen() {
        Store.put(ctx, "on", "1"); on = true
        ContextCompat.startForegroundService(ctx, Intent(ctx, WatchService::class.java))
    }
    fun stopListen() {
        Store.put(ctx, "on", "0"); on = false
        ctx.stopService(Intent(ctx, WatchService::class.java))
    }
    val perms = if (Build.VERSION.SDK_INT >= 33)
        arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.POST_NOTIFICATIONS)
    else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
        tick++
        if (pending && hasMedia(ctx)) startListen()
        pending = false
    }
    fun select(id: String) { active = id; Store.put(ctx, "active", id) }
    LaunchedEffect(tick, on, floatOn) {   // 刚授予悬浮窗权限回来时，补显示悬浮窗
        if (on && floatOn && Settings.canDrawOverlays(ctx)) Overlay.show(ctx, "● 监听中", Overlay.GREEN)
    }

    var imported by remember { mutableStateOf<List<Uri>>(emptyList()) }
    var busy by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    var picking by remember { mutableStateOf(false) }
    // 点「一键去水印」后得到的检测结果；非 null 表示处于「去水印预览」状态，此时「导出」保存的是去水印后的图
    var removed by remember { mutableStateOf<Map<Uri, RemoveResult>?>(null) }
    fun toast(t: String) = Toast.makeText(ctx, t, Toast.LENGTH_LONG).show()
    /** 一键去水印：只检测并更新预览，不保存；保存要点「导出」。 */
    fun analyzeRemove() {
        if (imported.isEmpty()) { toast("请先点「导入」选择照片"); return }
        if (busy.isNotEmpty()) return
        val list = imported
        scope.launch {
            val map = LinkedHashMap<Uri, RemoveResult>()
            for ((i, u) in list.withIndex()) {
                busy = "检测水印 ${i + 1}/${list.size}…"
                map[u] = withContext(Dispatchers.IO) {
                    runCatching { Processor.analyze(ctx, u) }.getOrDefault(RemoveResult.NONE)
                }
            }
            busy = ""
            val ok = map.values.count { it == RemoveResult.OK }
            val baked = map.values.count { it == RemoveResult.BAKED }
            val none = map.values.count { it == RemoveResult.NONE }
            val extra = StringBuilder()
            if (baked > 0) extra.append("；$baked 张水印直接画在照片上，无法去除（请使用相册里的原图）")
            if (none > 0) extra.append("；$none 张未检测到可去除的边框水印")
            if (ok == 0) { removed = null; toast("没有可去除水印的照片" + extra) }
            else { removed = map; toast("可去除 $ok 张，预览已更新，确认后点「导出」保存" + extra) }
        }
    }

    /** 导出：未去水印时 = 给导入的照片加当前样式水印（WM_）；去水印预览状态下 = 保存去水印后的图（NOWM_）。 */
    fun export() {
        if (imported.isEmpty()) { toast("请先点「导入」选择照片"); return }
        if (busy.isNotEmpty()) return
        val list = imported
        val plan = removed
        val targets = if (plan != null) list.filter { plan[it] == RemoveResult.OK } else list
        scope.launch {
            var ok = 0; var fail = 0
            for ((i, u) in targets.withIndex()) {
                busy = "导出 ${i + 1}/${targets.size}…"
                val r = withContext(Dispatchers.IO) {
                    runCatching {
                        val name = Processor.displayName(ctx, u)
                        if (plan != null) Processor.removeWatermark(ctx, u, name)
                        else { Processor.process(ctx, u, name, System.currentTimeMillis()); 0 }
                    }.getOrElse { 3 }
                }
                if (r == 0) ok++ else fail++
            }
            busy = ""
            if (plan != null) removed = null
            val msg = StringBuilder(if (plan != null) "已导出 $ok 张去水印的照片" else "已导出 $ok 张")
            if (ok > 0) msg.append("，保存在 Pictures/Watermark")
            if (plan != null && list.size > targets.size) msg.append("；${list.size - targets.size} 张无法去除水印，已跳过")
            if (fail > 0) msg.append("；$fail 张处理失败")
            toast(msg.toString())
        }
    }

    if (picking) {
        GalleryPicker(onCancel = { picking = false }) { us -> imported = (imported + us).distinct(); removed = null; picking = false }
        return
    }
    val e = editing
    if (e != null) {
        Editor(e, device, onCancel = { editing = null }) { s ->
            val u = Store.users(ctx); val i = u.indexOfFirst { it.id == s.id }
            if (i >= 0) u[i] = s else u.add(s)
            Store.saveUsers(ctx, u); styles = Store.all(ctx); select(s.id); editing = null
        }
        return
    }

    val cur = styles.firstOrNull { it.id == active } ?: styles[0]
    val pv = remember(cur, device) { Renderer.preview(cur, device, Renderer.logo(ctx, cur)) }
    val first = imported.firstOrNull()
    val shot by produceState<Pv?>(null, first, cur, device, removed) {
        value = if (first == null) null else withContext(Dispatchers.IO) {
            runCatching {
                if (removed != null) {
                    val r = Processor.removedPreview(ctx, first)
                    Pv(r.bmp, if (r.result == RemoveResult.OK) 2 else 1)
                } else Processor.previewOf(ctx, first, cur, device)
            }.getOrNull()
        }
    }
    val pkg = ctx.packageName
    val details = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
    val media = remember(tick) { hasMedia(ctx) }
    val notif = remember(tick) { hasNotif(ctx) }
    val battery = remember(tick) { noBatteryLimit(ctx) }
    val overlayOk = remember(tick) { Settings.canDrawOverlays(ctx) }
    val files = remember(tick) { allFiles() }
    val overlayIntent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$pkg"))
    val filesIntent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$pkg"))

    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("自动水印", style = MaterialTheme.typography.headlineSmall)
            Text("作者：xjbz常", style = MaterialTheme.typography.bodySmall)
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("监听模式", style = MaterialTheme.typography.titleMedium)
                    Text(if (on) "运行中：新拍的照片会自动加水印，保存到 Pictures/Watermark"
                         else "已停止", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button({ if (hasMedia(ctx)) startListen() else { pending = true; perm.launch(perms) } },
                            Modifier.weight(1f), enabled = !on) { Text("开始监听") }
                        OutlinedButton({ stopListen() }, Modifier.weight(1f), enabled = on) { Text("停止监听") }
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("保存原图")
                            Text(if (keep) "开：原图 + 水印图，共两张" else "关：只保留水印图，原图会被删除",
                                style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(keep, { v ->
                            keep = v; Store.put(ctx, "keep", if (v) "1" else "0")
                            if (!v && !allFiles()) open(ctx, filesIntent, details)
                        })
                    }
                    if (!keep && !files) Text("⚠ 还没授予「所有文件访问」权限，原图删不掉，暂时会保留两张",
                        style = MaterialTheme.typography.bodySmall, color = Color(0xFFC62828))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("监听悬浮窗")
                            Text("监听中显示绿色标签，关闭时红色提示，可拖动", style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(floatOn, { v ->
                            floatOn = v; Store.put(ctx, "float", if (v) "1" else "0")
                            if (v && !Settings.canDrawOverlays(ctx)) open(ctx, overlayIntent, details)
                            if (on) { if (v) Overlay.show(ctx, "● 监听中", Overlay.GREEN) else Overlay.hide() }
                        })
                    }
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Image((shot?.bmp ?: pv).asImageBitmap(), null, Modifier.fillMaxWidth().heightIn(max = 480.dp))
                val note = when (shot?.state) {
                    1 -> if (removed != null) "第 1 张无法去除水印，预览显示原图"
                         else "这张照片已带水印，预览显示原图（不再叠加样式）；点「一键去水印」查看去除后的效果"
                    2 -> "已去除水印的预览（第 1 张），确认后点「导出」保存"
                    else -> null
                }
                if (note != null) Text(note, style = MaterialTheme.typography.bodySmall)
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (busy.isNotEmpty() || imported.isNotEmpty()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (busy.isNotEmpty()) busy
                             else if (removed != null) "已导入 ${imported.size} 张 · 去水印预览中（尚未保存）"
                             else "已导入 ${imported.size} 张（预览为第 1 张）",
                            Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                        if (busy.isEmpty() && removed != null) TextButton({ removed = null }) { Text("撤销") }
                        if (busy.isEmpty()) TextButton({ imported = emptyList(); removed = null }) { Text("清空") }
                    }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    val pad = PaddingValues(horizontal = 8.dp)
                    OutlinedButton({
                        if (hasMedia(ctx)) picking = true
                        else { toast("请先授予相册权限，授予后再点导入"); perm.launch(perms) }
                    }, Modifier.weight(1f),
                        enabled = busy.isEmpty(), contentPadding = pad) { Text("导入", maxLines = 1) }
                    Button({ export() }, Modifier.weight(1f),
                        enabled = busy.isEmpty(), contentPadding = pad) { Text("导出", maxLines = 1) }
                    OutlinedButton({ analyzeRemove() }, Modifier.weight(2f),
                        enabled = busy.isEmpty(), contentPadding = pad) { Text("一键去水印", maxLines = 1) }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("水印样式", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                Button({ editing = WmStyle("u" + System.currentTimeMillis(), "我的水印",
                    leftTop = "{model}", leftBottom = "{datetime}", rightTop = "{params}") }) { Text("新建") }
            }
        }
        item {
            var expanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(expanded, { expanded = it }) {
                OutlinedTextField(
                    value = cur.name, onValueChange = {}, readOnly = true,
                    modifier = Modifier.menuAnchor().fillMaxWidth(),
                    label = { Text("当前样式") },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) })
                ExposedDropdownMenu(expanded, { expanded = false }) {
                    styles.forEach { s ->
                        DropdownMenuItem(
                            text = { Text(s.name) },
                            onClick = { select(s.id); expanded = false })
                    }
                }
            }
        }
        item {
            val builtin = Presets.all.any { it.id == cur.id }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically) {
                TextButton({ editing = if (builtin) cur.copy(id = "u" + System.currentTimeMillis(), name = cur.name + " 副本") else cur }) {
                    Text(if (builtin) "复制编辑" else "编辑")
                }
                if (!builtin) TextButton({
                    val u = Store.users(ctx).filter { it.id != cur.id }; Store.saveUsers(ctx, u)
                    styles = Store.all(ctx); select("mi_leica")
                }) { Text("删除") }
            }
        }
        item {
            OutlinedTextField(device, { device = it; Store.put(ctx, "device", it) }, Modifier.fillMaxWidth(),
                label = { Text("机型显示名（留空则读 EXIF，如填 Xiaomi 13）") }, singleLine = true)
        }
        item {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("权限与后台设置", style = MaterialTheme.typography.titleMedium)
                    PermRow("相册读取权限（需选「允许全部」）", media, "去开启") {
                        if (!media) perm.launch(perms) else open(ctx, details)
                    }
                    PermRow("通知权限（前台服务通知）", notif, "去开启") {
                        if (!notif) perm.launch(perms) else open(ctx,
                            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, pkg), details)
                    }
                    PermRow("电池无限制（防止后台被杀）", battery, "去开启") {
                        open(ctx,
                            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$pkg")),
                            Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS), details)
                    }
                    PermRow("自启动 / 后台运行（小米等机型）", null, "去设置") {
                        open(ctx,
                            Intent().setComponent(ComponentName("com.miui.securitycenter",
                                "com.miui.permcenter.autostart.AutoStartManagementActivity")), details)
                    }
                    PermRow("悬浮窗权限（显示监听状态）", overlayOk, "去开启") { open(ctx, overlayIntent, details) }
                    PermRow("所有文件访问（关闭「保存原图」删除原图需要）", files, "去开启") {
                        open(ctx, filesIntent, Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION), details)
                    }
                    OutlinedButton({ open(ctx, details) }, Modifier.fillMaxWidth()) { Text("打开本应用系统设置页") }
                }
            }
        }
        item {
            OutlinedTextField(watch, { watch = it; Store.put(ctx, "watch", it) }, Modifier.fillMaxWidth(),
                label = { Text("监听的相册路径（默认 DCIM/Camera）") }, singleLine = true)
        }
        item { Text("作者：xjbz常", style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
fun Editor(init: WmStyle, device: String, onCancel: () -> Unit, onSave: (WmStyle) -> Unit) {
    val ctx = LocalContext.current
    var s by remember { mutableStateOf(init) }
    var bg by remember { mutableStateOf(hex(init.bg)) }
    var fg by remember { mutableStateOf(hex(init.fg)) }
    var sub by remember { mutableStateOf(hex(init.subFg)) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? ->
        if (u != null) {
            runCatching { ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            s = s.copy(logoUri = u.toString())
        }
    }
    val pickFont = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? ->
        if (u != null) runCatching {
            val dir = java.io.File(ctx.filesDir, "fonts").apply { mkdirs() }
            val f = java.io.File(dir, "f" + System.currentTimeMillis() + ".ttf")
            ctx.contentResolver.openInputStream(u)!!.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            s = s.copy(fontPath = f.absolutePath)
        }
    }
    val pv = remember(s, device) { Renderer.preview(s, device, Renderer.logo(ctx, s)) }
    val bar = s.layout != Layout.OVERLAY      // BAR / FRAME / GLASS 都有左右两组文字

    BackHandler(onBack = onCancel)
    Column(Modifier.statusBarsPadding()) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        TextButton(onCancel) { Text("← 返回") }
        Spacer(Modifier.weight(1f))
        Button({ onSave(s) }) { Text("保存") }
    }
    Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Image(pv.asImageBitmap(), null, Modifier.fillMaxWidth())
        OutlinedTextField(s.name, { s = s.copy(name = it) }, Modifier.fillMaxWidth(), label = { Text("名称") }, singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(s.layout == Layout.BAR, { s = s.copy(layout = Layout.BAR) }, { Text("边框条") })
            FilterChip(s.layout == Layout.OVERLAY, { s = s.copy(layout = Layout.OVERLAY) }, { Text("照片角标") })
            FilterChip(s.layout == Layout.FRAME, { s = s.copy(layout = Layout.FRAME) }, { Text("全边框") })
            FilterChip(s.layout == Layout.GLASS, { s = s.copy(layout = Layout.GLASS) }, { Text("玻璃") })
        }
        OutlinedTextField(s.leftTop, { s = s.copy(leftTop = it) }, Modifier.fillMaxWidth(), label = { Text("左上（主文字）") })
        OutlinedTextField(s.leftBottom, { s = s.copy(leftBottom = it) }, Modifier.fillMaxWidth(), label = { Text("左下（副文字）") })
        if (bar) {
            OutlinedTextField(s.rightTop, { s = s.copy(rightTop = it) }, Modifier.fillMaxWidth(), label = { Text("右上") })
            OutlinedTextField(s.rightBottom, { s = s.copy(rightBottom = it) }, Modifier.fillMaxWidth(), label = { Text("右下") })
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("文字居中", Modifier.weight(1f)); Switch(s.center, { s = s.copy(center = it) })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("竖分隔线", Modifier.weight(1f)); Switch(s.divider, { s = s.copy(divider = it) })
            }
        } else {
            OutlinedTextField(s.rightTop, { s = s.copy(rightTop = it) }, Modifier.fillMaxWidth(), label = { Text("第三行（可留空，显示在最下面）") })
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(s.pos == Pos.BL, { s = s.copy(pos = Pos.BL) }, { Text("左下") })
                FilterChip(s.pos == Pos.BC, { s = s.copy(pos = Pos.BC) }, { Text("居中") })
                FilterChip(s.pos == Pos.BR, { s = s.copy(pos = Pos.BR) }, { Text("右下") })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("强调竖条（橙色）", Modifier.weight(1f))
                Switch(s.accent != 0, { s = s.copy(accent = if (it) 0xFFFF6A00.toInt() else 0) })
            }
        }
        if (s.layout == Layout.FRAME) {
            Text("边框粗细 %.1f%%".format(maxOf(s.frame, 0.035f) * 100))
            Slider(maxOf(s.frame, 0.035f), { s = s.copy(frame = it) }, valueRange = 0.02f..0.10f)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("胶片齿孔", Modifier.weight(1f)); Switch(s.perf, { s = s.copy(perf = it) })
            }
        }
        if (s.layout == Layout.GLASS) {
            val a = (s.bg ushr 24) / 255f
            Text("玻璃透明度 %d%%".format((a * 100).toInt()))
            Slider(a, { v -> s = s.copy(bg = ((v * 255).toInt() shl 24) or (s.bg and 0xFFFFFF)) }, valueRange = 0.1f..1f)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("内置徕卡红标", Modifier.weight(1f)); Switch(s.badge, { s = s.copy(badge = it) })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("斜体", Modifier.weight(1f)); Switch(s.italic, { s = s.copy(italic = it) })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(s.font == "sans", { s = s.copy(font = "sans") }, { Text("黑体") })
            FilterChip(s.font == "serif", { s = s.copy(font = "serif") }, { Text("衬线") })
            FilterChip(s.font == "mono", { s = s.copy(font = "mono") }, { Text("等宽") })
        }
        Text("字间距 %.2f".format(s.tracking))
        Slider(s.tracking, { s = s.copy(tracking = it) }, valueRange = 0f..0.5f)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Button({ pickFont.launch(arrayOf("*/*")) }) { Text(if (s.fontPath.isBlank()) "导入字体文件" else "更换字体文件") }
            if (s.fontPath.isNotBlank()) TextButton({ s = s.copy(fontPath = "") }) { Text("清除字体") }
        }
        Text("字体文件支持 .ttf / .otf；要显示中文，字体本身需包含中文字形。" +
            "局部加粗：用两个星号包住，如 **XIAOMI** 17 Ultra（含星号的行，其余部分为细体）",
            style = MaterialTheme.typography.bodySmall)
        Text("变量：{make} {model} {focal} {aperture} {shutter} {iso} {params} {params2} {date} {time} {datetime}",
            style = MaterialTheme.typography.bodySmall)
        OutlinedTextField(bg, { bg = it; parseHex(it)?.let { c -> s = s.copy(bg = (s.bg and 0xFF000000.toInt()) or (c and 0xFFFFFF)) } }, Modifier.fillMaxWidth(),
            label = { Text("背景色 RRGGBB（边框 / 玻璃底色）") }, singleLine = true)
        OutlinedTextField(fg, { fg = it; parseHex(it)?.let { c -> s = s.copy(fg = c) } }, Modifier.fillMaxWidth(),
            label = { Text("主文字颜色") }, singleLine = true)
        OutlinedTextField(sub, { sub = it; parseHex(it)?.let { c -> s = s.copy(subFg = c) } }, Modifier.fillMaxWidth(),
            label = { Text("副文字颜色") }, singleLine = true)
        Text("大小 %.1f×".format(s.scale))
        Slider(s.scale, { s = s.copy(scale = it) }, valueRange = 0.6f..1.6f)
        Text("自选图标 / Logo（所有版式通用，优先于内置红标；建议用透明底 PNG）", style = MaterialTheme.typography.bodySmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ pick.launch(arrayOf("image/*")) }) { Text(if (s.logoUri.isBlank()) "选择图标图片" else "更换图标图片") }
            if (s.logoUri.isNotBlank()) TextButton({ s = s.copy(logoUri = "") }) { Text("清除图标") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({ onSave(s) }) { Text("保存") }
            TextButton(onCancel) { Text("取消") }
        }
    }
    }
}
