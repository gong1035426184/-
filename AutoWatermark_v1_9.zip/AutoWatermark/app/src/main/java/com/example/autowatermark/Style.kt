package com.example.autowatermark

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

enum class Layout { BAR, OVERLAY, FRAME, GLASS }
enum class Pos { BL, BR, BC }

/**
 * 水印样式。文本里可用变量：
 * {make} {model} {focal} {aperture} {shutter} {iso} {params} {date} {time} {datetime}
 * 文字里用 **两个星号** 包住的片段为粗体，该行其余部分为细体。
 * BAR：照片下方追加白/黑边框条（左右各两行文字）；OVERLAY：直接叠加在照片角落；
 * FRAME：照片四周加边框，底部留文字区（胶片 / 拍立得风格）；GLASS：照片底部叠一块半透明磨砂玻璃卡片。
 */
data class WmStyle(
    val id: String,
    val name: String,
    val layout: Layout = Layout.BAR,
    val bg: Int = 0xFFFFFFFF.toInt(),
    val fg: Int = 0xFF111111.toInt(),
    val subFg: Int = 0xFF8A8A8A.toInt(),
    val leftTop: String = "",
    val leftBottom: String = "",
    val rightTop: String = "",
    val rightBottom: String = "",
    val divider: Boolean = false,
    val dot: Int = 0,               // 分隔线旁的圆点（如徕卡红点），0 = 不画
    val pos: Pos = Pos.BL,          // 仅 OVERLAY 使用
    val scale: Float = 1f,
    val logoUri: String = "",       // 可选：自选 Logo 图片，画在 BAR 左侧
    val badge: Boolean = false,     // 内置徕卡红标（红圆 + Leica）
    val italic: Boolean = false,    // 斜体
    val font: String = "sans",      // sans / serif / mono
    val frame: Float = 0f,          // FRAME 边框粗细（占短边比例，如 0.04）
    val perf: Boolean = false,      // FRAME 胶片齿孔
    val accent: Int = 0,            // OVERLAY 左侧强调竖条颜色，0 = 不画
    val center: Boolean = false,    // BAR / FRAME / GLASS 文字居中
    val fontPath: String = "",      // 自选字体文件（.ttf/.otf）路径，空 = 用 font 字段
    val tracking: Float = 0f,       // 主文字字间距（单位 em，如 0.2）
    val logoAsset: String = ""      // 内置 Logo（assets/logos/ 下的文件名），自选图标优先
) {
    fun toJson() = JSONObject().apply {
        put("id", id); put("name", name); put("layout", layout.name)
        put("bg", bg); put("fg", fg); put("subFg", subFg)
        put("lt", leftTop); put("lb", leftBottom); put("rt", rightTop); put("rb", rightBottom)
        put("div", divider); put("dot", dot); put("pos", pos.name)
        put("scale", scale.toDouble()); put("logo", logoUri)
        put("badge", badge); put("italic", italic); put("font", font)
        put("frame", frame.toDouble()); put("perf", perf); put("accent", accent); put("center", center); put("fontPath", fontPath); put("tracking", tracking.toDouble()); put("logoAsset", logoAsset)
    }

    companion object {
        fun fromJson(o: JSONObject) = WmStyle(
            o.getString("id"), o.getString("name"), Layout.valueOf(o.getString("layout")),
            o.getInt("bg"), o.getInt("fg"), o.getInt("subFg"),
            o.getString("lt"), o.getString("lb"), o.getString("rt"), o.getString("rb"),
            o.getBoolean("div"), o.getInt("dot"), Pos.valueOf(o.getString("pos")),
            o.getDouble("scale").toFloat(), o.optString("logo", ""),
            o.optBoolean("badge", false), o.optBoolean("italic", false), o.optString("font", "sans"),
            o.optDouble("frame", 0.0).toFloat(), o.optBoolean("perf", false),
            o.optInt("accent", 0), o.optBoolean("center", false), o.optString("fontPath", ""), o.optDouble("tracking", 0.0).toFloat(), o.optString("logoAsset", "")
        )
    }
}

object Presets {
    private const val WHITE = 0xFFFFFFFF.toInt()
    private const val SOFT = 0xCCFFFFFF.toInt()
    private const val P = "{params}"

    private const val RED = 0xFFE60012.toInt()
    private const val GLASS_LIGHT = 0x55FFFFFF
    private const val GLASS_DARK = 0x66000000

    val all = listOf(
        // ---------- 小米 / 徕卡 系列 ----------
        WmStyle("mi_center", "小米 · 居中红标（新机型样式）", layout = Layout.OVERLAY, pos = Pos.BC, badge = true,
            fg = WHITE, subFg = SOFT, scale = 0.62f, leftBottom = "{params2}", rightTop = "xiaomi 17 Ultra"),
        WmStyle("mi_live", "小米 · 新徕卡一瞬（Live Moment）", layout = Layout.OVERLAY, pos = Pos.BC, badge = true,
            fg = WHITE, subFg = SOFT, scale = 0.66f,
            leftTop = "Live Moment", leftBottom = "{params}", rightTop = "xiaomi 17 Ultra"),
        WmStyle("mi_leica", "小米 · 标准", leftTop = "xiaomi 17 Ultra", leftBottom = "Leica Camera",
            rightTop = P, rightBottom = "{datetime}", divider = true, dot = RED),
        WmStyle("mi_leica_logo", "小米 · 徕卡红标", leftTop = "xiaomi 17 Ultra", leftBottom = "Leica Camera",
            rightTop = P, rightBottom = "{datetime}", divider = true, badge = true),
        WmStyle("mi_leica_dark", "小米 · 徕卡红标（深色）", bg = 0xFF111111.toInt(), fg = WHITE, subFg = 0xFFAAAAAA.toInt(),
            leftTop = "xiaomi 17 Ultra", leftBottom = "Leica Camera",
            rightTop = P, rightBottom = "{datetime}", divider = true, badge = true),
        WmStyle("mi_moment", "徕卡一瞬", layout = Layout.FRAME, frame = 0.035f, center = true, badge = true,
            leftTop = "xiaomi 17 Ultra", leftBottom = "{params}   {datetime}", fg = 0xFF111111.toInt(), subFg = 0xFF777777.toInt()),
        WmStyle("mi_moment_dark", "徕卡一瞬（黑框）", layout = Layout.FRAME, frame = 0.035f, center = true, badge = true,
            bg = 0xFF0E0E0E.toInt(), fg = WHITE, subFg = 0xFFAAAAAA.toInt(),
            leftTop = "xiaomi 17 Ultra", leftBottom = "{params}   {datetime}"),
        WmStyle("mi_summilux", "小米 · Summilux", leftTop = "LEICA SUMMILUX", leftBottom = "xiaomi 17 Ultra",
            rightTop = P, rightBottom = "{datetime}", divider = true, font = "serif", badge = true),
        WmStyle("mi_film", "小米 · 胶片", layout = Layout.FRAME, frame = 0.055f, perf = true, center = true,
            bg = 0xFF121212.toInt(), fg = 0xFFFFB347.toInt(), subFg = 0xFFC98A2E.toInt(), font = "mono",
            leftTop = "{date}   xiaomi 17 Ultra", leftBottom = P),
        WmStyle("mi_sport", "小米 · 运动", layout = Layout.OVERLAY, fg = WHITE, subFg = SOFT,
            leftTop = P, leftBottom = "xiaomi 17 Ultra  ·  {datetime}", italic = true, accent = 0xFFFF6A00.toInt(), scale = 1.1f),
        WmStyle("mi_glass", "小米 · 透明玻璃", layout = Layout.GLASS, bg = GLASS_LIGHT, fg = WHITE, subFg = SOFT,
            leftTop = "xiaomi 17 Ultra", leftBottom = "Leica Camera", rightTop = P, rightBottom = "{datetime}", badge = true),
        WmStyle("mi_glass_dark", "小米 · 透明玻璃（深色）", layout = Layout.GLASS, bg = GLASS_DARK, fg = WHITE, subFg = SOFT,
            leftTop = "xiaomi 17 Ultra", leftBottom = "Leica Camera", rightTop = P, rightBottom = "{datetime}", badge = true),
        WmStyle("mi_glass_center", "小米 · 玻璃居中", layout = Layout.GLASS, bg = GLASS_LIGHT, fg = WHITE, subFg = SOFT,
            center = true, badge = true, leftTop = "xiaomi 17 Ultra", leftBottom = "{params}"),
        WmStyle("mi_classic", "小米 · Shot on 经典角标", layout = Layout.OVERLAY, fg = WHITE, subFg = SOFT,
            leftTop = "Shot on xiaomi 17 Ultra", leftBottom = "AI Camera"),
        // ---------- 融入图片的品牌 Logo（透明底，直接叠在照片底部居中） ----------
        WmStyle("oppo_hb", "OPPO · 哈苏（融入图片）", layout = Layout.OVERLAY, pos = Pos.BC, fg = WHITE, subFg = SOFT,
            scale = 0.7f, logoAsset = "oppo_hasselblad.png", leftBottom = "{model}"),
        WmStyle("oppo_hb_params", "OPPO · 哈苏（带参数）", layout = Layout.OVERLAY, pos = Pos.BC, fg = WHITE, subFg = SOFT,
            scale = 0.7f, logoAsset = "oppo_hasselblad.png", leftBottom = "{model}   {params}"),
        WmStyle("oppo_only", "OPPO · 纯 Logo", layout = Layout.OVERLAY, pos = Pos.BC, fg = WHITE, subFg = SOFT,
            scale = 0.7f, logoAsset = "oppo.png", leftBottom = "{model}   {params}"),
        WmStyle("hb_only", "哈苏 · H 标", layout = Layout.OVERLAY, pos = Pos.BC, fg = WHITE, subFg = SOFT,
            scale = 0.7f, logoAsset = "hasselblad_h.png", leftBottom = "{model}"),
        WmStyle("oneplus_hb", "一加 · 哈苏（融入图片）", layout = Layout.OVERLAY, pos = Pos.BC, fg = WHITE, subFg = SOFT,
            scale = 0.7f, logoAsset = "oneplus_hasselblad.png", leftBottom = "{model}   {params}"),
        WmStyle("oneplus_only", "一加 · 纯 Logo", layout = Layout.OVERLAY, pos = Pos.BC, fg = WHITE, subFg = SOFT,
            scale = 0.7f, logoAsset = "oneplus.png", leftBottom = "{model}   {params}"),
        WmStyle("vivo_zeiss", "vivo · 蔡司（融入图片）", layout = Layout.OVERLAY, pos = Pos.BC, fg = WHITE, subFg = SOFT,
            scale = 0.7f, logoAsset = "vivo_zeiss.png", leftBottom = "{model}   {params}"),
        WmStyle("vivo_only", "vivo · 纯 Logo", layout = Layout.OVERLAY, pos = Pos.BC, fg = WHITE, subFg = SOFT,
            scale = 0.7f, logoAsset = "vivo.png", leftBottom = "{model}   {params}"),
        WmStyle("zeiss_only", "蔡司 · 纯 Logo", layout = Layout.OVERLAY, pos = Pos.BC, fg = WHITE, subFg = SOFT,
            scale = 0.7f, logoAsset = "zeiss.png", leftBottom = "{model}"),
        WmStyle("huawei_xmage", "华为（融入图片）", layout = Layout.OVERLAY, pos = Pos.BC, fg = WHITE, subFg = SOFT,
            scale = 0.7f, logoAsset = "huawei.png", leftBottom = "{model}   {params}"),
        WmStyle("honor_o", "荣耀（融入图片）", layout = Layout.OVERLAY, pos = Pos.BC, fg = WHITE, subFg = SOFT,
            scale = 0.7f, logoAsset = "honor.png", leftBottom = "{model}   {params}"),
        WmStyle("samsung_o", "三星（融入图片）", layout = Layout.OVERLAY, pos = Pos.BC, fg = WHITE, subFg = SOFT,
            scale = 0.7f, logoAsset = "samsung.png", leftBottom = "{model}   {params}"),
        WmStyle("apple_logo", "苹果 · Logo + Shot on", layout = Layout.OVERLAY, pos = Pos.BC, fg = WHITE, subFg = SOFT,
            scale = 0.7f, logoAsset = "apple.png", leftTop = "Shot on {model}", leftBottom = "{params}"),
        // ---------- 其他品牌（边框条等） ----------
        WmStyle("huawei", "华为 · XMAGE（边框条）", leftTop = "{model}", leftBottom = "HUAWEI XMAGE",
            rightTop = P, rightBottom = "{datetime}", divider = true),
        WmStyle("vivo", "vivo · 蔡司（边框条）", leftTop = "{model}", leftBottom = "ZEISS",
            rightTop = P, rightBottom = "{datetime}", divider = true),
        WmStyle("oppo", "OPPO · 哈苏（边框条）", leftTop = "{model}", leftBottom = "Hasselblad Master Camera",
            rightTop = P, rightBottom = "{datetime}", divider = true),
        WmStyle("honor", "荣耀（边框条）", leftTop = "HONOR {model}", leftBottom = "{datetime}",
            rightTop = P, divider = true),
        WmStyle("oneplus", "一加 · 暗色（边框条）", bg = 0xFF111111.toInt(), fg = WHITE, subFg = 0xFFAAAAAA.toInt(),
            leftTop = "{model}", leftBottom = "Hasselblad Camera for Mobile",
            rightTop = P, rightBottom = "{datetime}", divider = true, dot = 0xFFEB0028.toInt()),
        WmStyle("samsung", "三星 · Shot on Galaxy", layout = Layout.OVERLAY, fg = WHITE, subFg = SOFT,
            leftTop = "Shot on {model}", leftBottom = P),
        WmStyle("apple", "苹果 · Shot on iPhone", layout = Layout.OVERLAY, pos = Pos.BC, fg = WHITE, subFg = SOFT,
            leftTop = "Shot on {model}"),
        WmStyle("minimal", "极简参数条", leftTop = "{model}", leftBottom = "{datetime}", rightTop = P),
        WmStyle("polaroid", "拍立得白框", layout = Layout.FRAME, frame = 0.05f, center = true,
            fg = 0xFF333333.toInt(), subFg = 0xFF999999.toInt(), leftTop = "{date}", leftBottom = "{model}"),
        WmStyle("film_stamp", "胶片日期戳", layout = Layout.OVERLAY, pos = Pos.BR, fg = 0xFFFF9A2E.toInt(),
            leftTop = "{date}")
    )
}

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("wm", Context.MODE_PRIVATE)
    fun str(c: Context, k: String, d: String): String = sp(c).getString(k, d) ?: d
    fun put(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()

    fun users(c: Context): MutableList<WmStyle> {
        val a = JSONArray(str(c, "users", "[]"))
        return MutableList(a.length()) { WmStyle.fromJson(a.getJSONObject(it)) }
    }
    fun saveUsers(c: Context, l: List<WmStyle>) = put(c, "users", JSONArray(l.map { it.toJson() }).toString())
    fun all(c: Context): List<WmStyle> = Presets.all + users(c)
    fun active(c: Context): WmStyle {
        val l = all(c); val id = str(c, "active", "mi_leica")
        return l.firstOrNull { it.id == id } ?: l[0]
    }
}
