package com.example.autowatermark

import android.app.*
import android.content.ContentUris
import android.content.Intent
import android.content.pm.ServiceInfo
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.provider.MediaStore.Images.Media as M
import java.util.concurrent.Executors

class WatchService : Service() {
    private val EXT: Uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    private val h = Handler(Looper.getMainLooper())
    private val exec = Executors.newSingleThreadExecutor()
    private val fails = HashMap<Long, Int>()
    private val scan = Runnable { exec.execute { scanNew() } }

    // 相机写入照片时会触发多次回调，做个防抖
    private val obs = object : ContentObserver(h) {
        override fun onChange(selfChange: Boolean) {
            h.removeCallbacks(scan); h.postDelayed(scan, 1500)
        }
    }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("watch", "相册监听", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "watch")
            .setContentTitle("自动水印运行中").setContentText("正在监听新照片")
            .setSmallIcon(android.R.drawable.ic_menu_camera).setOngoing(true).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        // 以启动时刻的最大 ID 为基线：只处理此后新增的照片
        exec.execute { Store.put(this, "last", maxId().toString()) }
        contentResolver.registerContentObserver(EXT, true, obs)
        Overlay.show(this, "● 监听中", Overlay.GREEN)
    }

    override fun onDestroy() {
        contentResolver.unregisterContentObserver(obs)
        h.removeCallbacksAndMessages(null)
        exec.shutdown()
        Overlay.show(this, "● 监听已关闭", Overlay.RED, 2500)
        super.onDestroy()
    }

    private fun maxId(): Long =
        contentResolver.query(EXT, arrayOf(MediaStore.Images.Media._ID), null, null, "_id DESC")?.use {
            if (it.moveToFirst()) it.getLong(0) else 0L
        } ?: 0L

    private fun scanNew() {
        val last = Store.str(this, "last", "0").toLong()
        val watch = Store.str(this, "watch", "DCIM/Camera").trim().trim('/').ifBlank { "DCIM/Camera" }
        val c = contentResolver.query(
            EXT, arrayOf(M._ID, M.DISPLAY_NAME, M.DATE_TAKEN, M.MIME_TYPE),
            "${M._ID} > ? AND ${M.RELATIVE_PATH} LIKE ? AND ${M.IS_PENDING} = 0",
            arrayOf(last.toString(), "$watch/%"), "${M._ID} ASC"
        ) ?: return
        var retry = false
        c.use {
            while (it.moveToNext()) {
                val id = it.getLong(0); val name = it.getString(1) ?: "img"
                val taken = it.getLong(2); val mime = it.getString(3) ?: ""
                if (name.startsWith("WM_") || name.startsWith("NOWM_") || !mime.startsWith("image/")) {
                    Store.put(this, "last", id.toString()); continue
                }
                try {
                    Overlay.show(this, "◌ 处理中…", Overlay.ORANGE)
                    val uri = ContentUris.withAppendedId(EXT, id)
                    Processor.process(this, uri, name, if (taken > 0) taken else System.currentTimeMillis())
                    Store.put(this, "last", id.toString())
                    if (Store.str(this, "keep", "1") == "0") {
                        if (Processor.deleteOriginal(this, uri)) Overlay.show(this, "✓ 已加水印，原图已删除", Overlay.GREEN)
                        else Overlay.show(this, "⚠ 水印已保存，原图未能删除", Overlay.ORANGE)
                    } else Overlay.show(this, "✓ 已加水印", Overlay.GREEN)
                    h.postDelayed({ Overlay.show(this, "● 监听中", Overlay.GREEN) }, 2500)
                } catch (e: Throwable) {
                    h.postDelayed({ Overlay.show(this, "● 监听中", Overlay.GREEN) }, 2500)
                    val n = (fails[id] ?: 0) + 1; fails[id] = n
                    if (n < 3) { retry = true; break } else Store.put(this, "last", id.toString())
                }
            }
        }
        if (retry) h.postDelayed(scan, 2500)
    }
}
