package com.example.autowatermark

import android.content.ContentValues
import android.content.Context
import android.graphics.*
import android.media.MediaScannerConnection
import java.io.File
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.exifinterface.media.ExifInterface
import java.text.SimpleDateFormat
import java.util.*

data class PhotoInfo(
    val make: String, val model: String, val focal: String,
    val aperture: String, val shutter: String, val iso: String, val time: Long,
    val fnum: Double = 0.0
)

object Renderer {
    fun readInfo(e: ExifInterface, fallbackTime: Long): PhotoInfo {
        val f35 = e.getAttributeInt(ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM, 0)
        val f = if (f35 > 0) f35.toDouble() else e.getAttributeDouble(ExifInterface.TAG_FOCAL_LENGTH, 0.0)
        val fn = e.getAttributeDouble(ExifInterface.TAG_F_NUMBER, 0.0)
        val ex = e.getAttributeDouble(ExifInterface.TAG_EXPOSURE_TIME, 0.0)
        val iso = e.getAttributeInt(ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY, 0)
        val t = runCatching {
            SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US)
                .parse(e.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL) ?: "")?.time
        }.getOrNull() ?: fallbackTime
        return PhotoInfo(
            e.getAttribute(ExifInterface.TAG_MAKE) ?: "",
            e.getAttribute(ExifInterface.TAG_MODEL) ?: "",
            if (f > 0) "${Math.round(f)}mm" else "",
            if (fn > 0) "f/%.1f".format(fn) else "",
            when {
                ex <= 0 -> ""
                ex >= 1 -> "%.1fs".format(ex)
                else -> "1/${Math.round(1 / ex)}s"
            },
            if (iso > 0) "ISO$iso" else "",
            t,
            fn
        )
    }

    fun fill(t: String, i: PhotoInfo, device: String): String {
        if (t.isBlank()) return ""
        val model = device.ifBlank { i.model.ifBlank { Build.MODEL } }
        val d = Date(i.time)
        fun fmt(p: String) = SimpleDateFormat(p, Locale.getDefault()).format(d)
        val params = listOf(i.focal, i.aperture, i.shutter, i.iso).filter { it.isNotEmpty() }.joinToString("  ")
        val ap2 = if (i.fnum > 0) "1/%.2f".format(i.fnum) else ""
        val params2 = listOf(i.focal, ap2, i.shutter, i.iso).filter { it.isNotEmpty() }.joinToString("  ")
        return t.replace("{params2}", params2).replace("{make}", i.make).replace("{model}", model)
            .replace("{focal}", i.focal).replace("{aperture}", i.aperture)
            .replace("{shutter}", i.shutter).replace("{iso}", i.iso).replace("{params}", params)
            .replace("{date}", fmt("yyyy.MM.dd")).replace("{time}", fmt("HH:mm"))
            .replace("{datetime}", fmt("yyyy.MM.dd HH:mm"))
            .replace(Regex(" {3,}"), "  ").trim()
    }

    /** 自选图标优先；其次预设自带的 assets/logos；开了「徕卡红标」则用内置 leica.png */
    fun logo(ctx: Context, st: WmStyle): Bitmap? {
        val fromUri = if (st.logoUri.isBlank()) null else runCatching {
            ctx.contentResolver.openInputStream(Uri.parse(st.logoUri))!!.use { BitmapFactory.decodeStream(it) }
        }.getOrNull()
        if (fromUri != null) return fromUri
        val asset = when {
            st.logoAsset.isNotBlank() -> st.logoAsset
            st.badge -> "leica.png"
            else -> ""
        }
        if (asset.isBlank()) return null
        return runCatching {
            ctx.assets.open("logos/" + asset).use { BitmapFactory.decodeStream(it) }
        }.getOrNull()
    }

    /** 过宽的字标类 Logo 按最大宽度缩小高度 */
    private fun fitH(logo: Bitmap?, mh: Float, maxW: Float): Float =
        if (logo == null) mh else minOf(mh, maxW * logo.height / logo.width)

    private const val WHITE = 0xFFFFFFFF.toInt()

    private fun faces(st: WmStyle): Pair<Paint, Paint> {
        val custom = if (st.fontPath.isBlank()) null
            else runCatching { Typeface.createFromFile(st.fontPath) }.getOrNull()
        val base = custom ?: when (st.font) {
            "serif" -> Typeface.SERIF
            "mono" -> Typeface.MONOSPACE
            else -> Typeface.DEFAULT
        }
        val bold = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create(base, if (st.italic) Typeface.BOLD_ITALIC else Typeface.BOLD)
            letterSpacing = st.tracking
        }
        val reg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create(base, if (st.italic) Typeface.ITALIC else Typeface.NORMAL)
            letterSpacing = st.tracking * 0.3f
        }
        return Pair(bold, reg)
    }

    /** 内置徕卡红标：红圆 + 白色斜体 Leica */
    private fun drawBadge(c: Canvas, cx: Float, cy: Float, r: Float) {
        c.drawCircle(cx, cy, r, Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE60012.toInt() })
        val t = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = WHITE
            typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC)
            textAlign = Paint.Align.CENTER
            textSize = r * 0.62f
        }
        val w = t.measureText("Leica")
        if (w > r * 1.5f) t.textSize = t.textSize * (r * 1.5f) / w
        val fm = t.fontMetrics
        c.drawText("Leica", cx, cy - (fm.ascent + fm.descent) / 2f, t)
    }

    private fun hasMark(st: WmStyle, logo: Bitmap?) = logo != null || st.badge
    private fun markWidth(logo: Bitmap?, mh: Float) =
        if (logo != null) logo.width * mh / logo.height else mh

    /** 画标记：自选 Logo 优先，其次内置红标。x 为左边缘，yMid 为垂直中心，mh 为高度 */
    private fun drawMark(c: Canvas, st: WmStyle, logo: Bitmap?, x: Float, yMid: Float, mh: Float) {
        if (logo != null) {
            val lw = markWidth(logo, mh)
            c.drawBitmap(logo, null, RectF(x, yMid - mh / 2, x + lw, yMid + mh / 2), Paint(Paint.FILTER_BITMAP_FLAG))
        } else if (st.badge) drawBadge(c, x + mh / 2, yMid, mh / 2)
    }

    /** 带 **粗体** 标记的文字宽度；无标记时按 dflt 计算 */
    private fun richWidth(t: String, bold: Paint, reg: Paint, dflt: Paint): Float {
        if (!t.contains("**")) return dflt.measureText(t)
        var sum = 0f
        t.split("**").forEachIndexed { idx, seg -> sum += (if (idx % 2 == 1) bold else reg).measureText(seg) }
        return sum
    }

    private fun drawRich(c: Canvas, t: String, x: Float, y: Float, align: Paint.Align,
                         bold: Paint, reg: Paint, dflt: Paint) {
        if (!t.contains("**")) { dflt.textAlign = align; c.drawText(t, x, y, dflt); return }
        val w = richWidth(t, bold, reg, dflt)
        var cx = when (align) {
            Paint.Align.LEFT -> x
            Paint.Align.RIGHT -> x - w
            else -> x - w / 2f
        }
        t.split("**").forEachIndexed { idx, seg ->
            val p = if (idx % 2 == 1) bold else reg
            p.textAlign = Paint.Align.LEFT
            c.drawText(seg, cx, y, p)
            cx += p.measureText(seg)
        }
    }

    /** 垂直居中于 yMid 的两行文字（主文字 + 副文字），字号取 bold / reg 当前的 textSize */
    private fun textBlock(c: Canvas, top: String, bot: String, x: Float, yMid: Float,
                          align: Paint.Align, bold: Paint, reg: Paint) {
        bold.textAlign = align; reg.textAlign = align
        val big = bold.textSize; val small = reg.textSize
        when {
            top.isNotEmpty() && bot.isNotEmpty() -> {
                val gap = big * 0.35f
                val t0 = yMid - (big + gap + small) / 2f
                drawRich(c, top, x, t0 + big * 0.8f, align, bold, reg, bold)
                drawRich(c, bot, x, t0 + big + gap + small * 0.8f, align, bold, reg, reg)
            }
            top.isNotEmpty() -> drawRich(c, top, x, yMid + big * 0.35f, align, bold, reg, bold)
            bot.isNotEmpty() -> drawRich(c, bot, x, yMid + small * 0.35f, align, bold, reg, reg)
        }
    }

    private class Ln(val t: String, val p: Paint, val size: Float)

    /** 多行文字总高度：第一行（大字）后的间距较大，其余行间距较小 */
    private fun linesH(ls: List<Ln>, big: Float, small: Float): Float {
        var h = 0f
        ls.forEachIndexed { i, l ->
            if (i > 0) h += if (ls[i - 1].size == big) big * 0.35f else small * 0.45f
            h += l.size
        }
        return h
    }

    /** 垂直居中于 yMid 的 2~3 行文字，每行用自己的字号 / 画笔 */
    private fun drawLines(c: Canvas, ls: List<Ln>, x: Float, yMid: Float, align: Paint.Align,
                          bold: Paint, reg: Paint, big: Float, small: Float) {
        var y = yMid - linesH(ls, big, small) / 2f
        ls.forEachIndexed { i, l ->
            if (i > 0) y += if (ls[i - 1].size == big) big * 0.35f else small * 0.45f
            l.p.textAlign = align
            drawRich(c, l.t, x, y + l.size * 0.8f, align, bold, reg, l.p)
            y += l.size
        }
    }

    /** BAR / FRAME / GLASS 共用的一行：[标记] 左文字 ……… 右文字。unit 为参考行高。 */
    private fun captionRow(c: Canvas, st: WmStyle, logo: Bitmap?, lt: String, lb: String, rt: String, rb: String,
                           x0: Float, x1: Float, yMid: Float, unit: Float, bold: Paint, reg: Paint) {
        bold.textSize = unit * 0.27f; reg.textSize = unit * 0.2f
        val mh = fitH(logo, unit * 0.5f, unit * 2.6f)
        val mark = hasMark(st, logo)
        val markW = if (mark) markWidth(logo, mh) else 0f
        val pad = unit * 0.5f
        val textW = maxOf(richWidth(lt, bold, reg, bold), richWidth(lb, bold, reg, reg))
        if (st.center) {
            val gap = if (mark && textW > 0f) pad * 0.5f else 0f
            var x = (x0 + x1) / 2f - (markW + gap + textW) / 2f
            if (mark) { drawMark(c, st, logo, x, yMid, mh); x += markW + gap }
            textBlock(c, lt, lb, x, yMid, Paint.Align.LEFT, bold, reg)
            return
        }
        var lx = x0 + pad
        if (mark) { drawMark(c, st, logo, lx, yMid, mh); lx += markW + pad * 0.5f }
        textBlock(c, lt, lb, lx, yMid, Paint.Align.LEFT, bold, reg)
        if (rt.isNotEmpty() || rb.isNotEmpty()) {
            textBlock(c, rt, rb, x1 - pad, yMid, Paint.Align.RIGHT, bold, reg)
            val bw = maxOf(richWidth(rt, bold, reg, bold), richWidth(rb, bold, reg, reg))
            val dx = x1 - pad - bw - pad * 0.7f
            if (st.divider) c.drawLine(dx, yMid - unit * 0.25f, dx, yMid + unit * 0.25f,
                Paint().apply { color = (st.subFg and 0x00FFFFFF) or 0x66000000; strokeWidth = maxOf(2f, unit * 0.012f) })
            if (st.dot != 0) c.drawCircle(dx - pad * 0.6f - unit * 0.11f, yMid, unit * 0.11f,
                Paint(Paint.ANTI_ALIAS_FLAG).apply { color = st.dot })
        }
    }

    /** src 必须是可变位图。BAR / FRAME 返回新位图（更大），OVERLAY / GLASS 直接在 src 上绘制。 */
    fun render(src: Bitmap, i: PhotoInfo, st: WmStyle, device: String, logo: Bitmap?): Bitmap {
        val lt = fill(st.leftTop, i, device); val lb = fill(st.leftBottom, i, device)
        val rt = fill(st.rightTop, i, device); val rb = fill(st.rightBottom, i, device)
        val w = src.width; val h = src.height
        val s = minOf(w, h) * st.scale
        val (bold, reg) = faces(st)
        bold.color = st.fg; reg.color = st.subFg

        return when (st.layout) {
            Layout.OVERLAY -> {
                val c = Canvas(src)
                val m = s * 0.05f; val big = s * 0.038f; val small = s * 0.028f
                bold.textSize = big; reg.textSize = small
                bold.setShadowLayer(big * 0.2f, 0f, 0f, 0x99000000.toInt())
                reg.setShadowLayer(small * 0.2f, 0f, 0f, 0x99000000.toInt())
                val two = lt.isNotEmpty() && lb.isNotEmpty()
                // 第三行（rightTop）：居中版式可用，字号介于大小字之间，略带字距
                val mid = small * 1.15f
                val p3 = Paint(bold).apply { textSize = mid; letterSpacing = maxOf(st.tracking, 0.05f) }
                val three = rt.isNotEmpty()
                val lines = listOf(Ln(lt, bold, big), Ln(lb, reg, small), Ln(rt, p3, mid)).filter { it.t.isNotEmpty() }
                val blockH = when {
                    three -> linesH(lines, big, small)
                    two -> big + big * 0.35f + small
                    lt.isNotEmpty() -> big
                    lb.isNotEmpty() -> small
                    else -> 0f
                }
                val textW = maxOf(richWidth(lt, bold, reg, bold), richWidth(lb, bold, reg, reg),
                    if (three) richWidth(rt, bold, reg, p3) else 0f)
                fun put(x: Float, yMid: Float, al: Paint.Align) =
                    if (three) drawLines(c, lines, x, yMid, al, bold, reg, big, small)
                    else textBlock(c, lt, lb, x, yMid, al, bold, reg)
                val mark = hasMark(st, logo)
                val mh = fitH(logo, if (st.pos == Pos.BC) s * 0.09f else maxOf(blockH, s * 0.06f), s * 0.4f)
                val markW = if (mark) markWidth(logo, mh) else 0f
                val gap = if (st.pos == Pos.BC) s * 0.03f else s * 0.018f
                val accW = if (st.accent != 0) s * 0.008f else 0f
                val accPaint = Paint().apply { color = st.accent }
                val bottom = h - m
                if (st.pos == Pos.BC) {
                    val cx = w / 2f
                    if (mark) drawMark(c, st, logo, cx - markW / 2f, bottom - blockH - gap - mh / 2f, mh)
                    put(cx, bottom - blockH / 2f, Paint.Align.CENTER)
                } else {
                    val rowH = if (mark) maxOf(blockH, mh) else blockH
                    val yMid = bottom - rowH / 2f
                    if (st.pos == Pos.BL) {
                        var x = m
                        if (accW > 0f) { c.drawRect(x, yMid - rowH / 2f, x + accW, yMid + rowH / 2f, accPaint); x += accW + gap }
                        if (mark) { drawMark(c, st, logo, x, yMid, mh); x += markW + gap }
                        put(x, yMid, Paint.Align.LEFT)
                    } else {
                        var x = w - m
                        if (accW > 0f) { c.drawRect(x - accW, yMid - rowH / 2f, x, yMid + rowH / 2f, accPaint); x -= accW + gap }
                        put(x, yMid, Paint.Align.RIGHT)
                        x -= textW + gap
                        if (mark) drawMark(c, st, logo, x - markW, yMid, mh)
                    }
                }
                src
            }

            Layout.GLASS -> {
                val c = Canvas(src)
                val m = s * 0.03f; val cardH = s * 0.12f
                val rect = RectF(m, h - m - cardH, w - m, h - m)
                val rad = cardH * 0.28f
                val l = rect.left.toInt(); val t = rect.top.toInt()
                val rw = rect.width().toInt(); val rh = rect.height().toInt()
                if (rw > 8 && rh > 8 && l >= 0 && t >= 0 && l + rw <= w && t + rh <= h) {
                    val crop = Bitmap.createBitmap(src, l, t, rw, rh)
                    val tiny = Bitmap.createScaledBitmap(crop, maxOf(2, rw / 24), maxOf(2, rh / 24), true)
                    val blur = Bitmap.createScaledBitmap(tiny, rw, rh, true)
                    c.save()
                    c.clipPath(Path().apply { addRoundRect(rect, rad, rad, Path.Direction.CW) })
                    c.drawBitmap(blur, l.toFloat(), t.toFloat(), null)
                    c.drawRect(rect, Paint().apply { color = st.bg })
                    c.restore()
                    crop.recycle(); tiny.recycle(); blur.recycle()
                }
                c.drawRoundRect(rect, rad, rad, Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    style = Paint.Style.STROKE; strokeWidth = maxOf(2f, cardH * 0.012f); color = 0x66FFFFFF
                })
                captionRow(c, st, logo, lt, lb, rt, rb, rect.left, rect.right, rect.centerY(), cardH, bold, reg)
                src
            }

            Layout.FRAME -> {
                val b = s * (if (st.frame > 0f) st.frame else 0.035f)
                val side = if (st.perf) b * 0.35f else b
                val cap = s * 0.10f
                val outW = (w + 2 * side).toInt(); val outH = (h + b + b + cap).toInt()
                val out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
                val c = Canvas(out)
                c.drawColor(st.bg)
                c.drawBitmap(src, side.toInt().toFloat(), b.toInt().toFloat(), null)
                if (st.perf) {
                    val hp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE8E8E8.toInt() }
                    val hw = b * 0.45f; val hh = b * 0.32f; val step = b * 0.9f
                    var x = step / 2f
                    while (x + hw < outW) {
                        val y1 = (b - hh) / 2f
                        val y2 = outH - b + (b - hh) / 2f
                        c.drawRoundRect(RectF(x, y1, x + hw, y1 + hh), hh * 0.25f, hh * 0.25f, hp)
                        c.drawRoundRect(RectF(x, y2, x + hw, y2 + hh), hh * 0.25f, hh * 0.25f, hp)
                        x += step
                    }
                }
                captionRow(c, st, logo, lt, lb, rt, rb, side, outW - side, b + h + cap / 2f, cap, bold, reg)
                out
            }

            Layout.BAR -> {
                val barH = s * 0.1f
                val out = Bitmap.createBitmap(w, (h + barH).toInt(), Bitmap.Config.ARGB_8888)
                val c = Canvas(out)
                c.drawBitmap(src, 0f, 0f, null)
                c.drawRect(0f, h.toFloat(), w.toFloat(), out.height.toFloat(), Paint().apply { color = st.bg })
                captionRow(c, st, logo, lt, lb, rt, rb, 0f, w.toFloat(), h + barH / 2f, barH, bold, reg)
                out
            }
        }
    }

    /** 渲染后原照片所在的矩形 [left, top, width, height]；OVERLAY / GLASS 直接画在照片上，返回 null。 */
    fun box(w: Int, h: Int, st: WmStyle): IntArray? {
        val s = minOf(w, h) * st.scale
        return when (st.layout) {
            Layout.BAR -> intArrayOf(0, 0, w, h)
            Layout.FRAME -> {
                val b = s * (if (st.frame > 0f) st.frame else 0.035f)
                val side = if (st.perf) b * 0.35f else b
                intArrayOf(side.toInt(), b.toInt(), w, h)
            }
            else -> null
        }
    }

    fun preview(st: WmStyle, device: String, logo: Bitmap?): Bitmap {
        val b = Bitmap.createBitmap(1200, 900, Bitmap.Config.ARGB_8888)
        Canvas(b).drawPaint(Paint().apply {
            shader = LinearGradient(0f, 0f, 1200f, 900f, 0xFF4A90D9.toInt(), 0xFFF5A66B.toInt(), Shader.TileMode.CLAMP)
        })
        val info = PhotoInfo("Xiaomi", "2211133C", "23mm", "f/1.8", "1/120s", "ISO100", System.currentTimeMillis())
        return render(b, info, st, device, logo)
    }
}

enum class RemoveResult { OK, BAKED, NONE }

/** 主界面预览：state 0 = 当前样式渲染的加水印效果；1 = 照片已带水印（显示原图，不再叠加）；2 = 去水印后的效果 */
class Pv(val bmp: Bitmap, val state: Int)
class RemovePreview(val result: RemoveResult, val bmp: Bitmap)

object Processor {
    private val EXIF_COPY = listOf(
        ExifInterface.TAG_MAKE, ExifInterface.TAG_MODEL, ExifInterface.TAG_DATETIME,
        ExifInterface.TAG_DATETIME_ORIGINAL, ExifInterface.TAG_F_NUMBER, ExifInterface.TAG_EXPOSURE_TIME,
        ExifInterface.TAG_PHOTOGRAPHIC_SENSITIVITY, ExifInterface.TAG_FOCAL_LENGTH,
        ExifInterface.TAG_FOCAL_LENGTH_IN_35MM_FILM
    )
    /** 写进输出图 EXIF「图像描述」里的标记，用来精确还原：AW1|宽|高|left|top|w|h|版式（无边框版式则 left..h 为 none） */
    private const val MARK = "AW1"

    /** 导入的照片 uri → 文件名 */
    fun displayName(ctx: Context, uri: Uri): String {
        var n: String? = null
        runCatching {
            ctx.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) n = it.getString(0)
            }
        }
        return n ?: ("img_" + System.currentTimeMillis() + ".jpg")
    }

    /** 读取照片 → 加水印 → 另存为 Pictures/Watermark/WM_xxx.jpg（保留原图）。失败会抛异常。 */
    fun process(ctx: Context, uri: Uri, name: String, takenMs: Long) {
        val cr = ctx.contentResolver
        val st = Store.active(ctx); val device = Store.str(ctx, "device", "")
        val exif = cr.openInputStream(uri)!!.use { ExifInterface(it) }
        val info = Renderer.readInfo(exif, takenMs)
        val orient = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
        val logo = Renderer.logo(ctx, st)

        var out: Pair<Bitmap, IntArray?>? = null
        for (sample in intArrayOf(1, 2, 4)) {
            try { out = build(ctx, uri, sample, orient, info, st, device, logo); break }
            catch (e: OutOfMemoryError) { System.gc() }
        }
        val (bmp, box) = out ?: error("内存不足")
        val mark = MARK + "|" + bmp.width + "|" + bmp.height + "|" +
            (if (box != null) box.joinToString("|") else "none|none|none|none") + "|" + st.layout.name
        save(ctx, bmp, "WM_" + name.substringBeforeLast('.') + ".jpg", info.time, exif, mark)
    }

    /** 把位图写入 Pictures/Watermark，并复制拍摄参数 EXIF。会回收 bmp。 */
    private fun save(ctx: Context, bmp: Bitmap, fileName: String, time: Long, exif: ExifInterface, mark: String?) {
        val cr = ctx.contentResolver
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Watermark")
            put(MediaStore.Images.Media.DATE_TAKEN, time)
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val dst = cr.insert(MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), v)!!
        try {
            cr.openOutputStream(dst)!!.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            runCatching {
                cr.openFileDescriptor(dst, "rw")?.use { pfd ->
                    val e = ExifInterface(pfd.fileDescriptor)
                    for (t in EXIF_COPY) exif.getAttribute(t)?.let { e.setAttribute(t, it) }
                    if (mark != null) e.setAttribute(ExifInterface.TAG_IMAGE_DESCRIPTION, mark)
                    e.saveAttributes()
                }
            }
            cr.update(dst, ContentValues().apply { put(MediaStore.Images.Media.IS_PENDING, 0) }, null, null)
        } catch (t: Throwable) {
            cr.delete(dst, null, null); throw t
        } finally { bmp.recycle() }
    }

    /** 删除原图：需要「所有文件访问」权限（Android 11+）才能删别的 App 写入的照片。 */
    fun deleteOriginal(ctx: Context, uri: Uri): Boolean {
        val cr = ctx.contentResolver
        var path: String? = null
        runCatching {
            cr.query(uri, arrayOf(MediaStore.Images.Media.DATA), null, null, null)?.use {
                if (it.moveToFirst()) path = it.getString(0)
            }
        }
        if (runCatching { cr.delete(uri, null, null) > 0 }.getOrDefault(false)) return true
        val p = path ?: return false
        val ok = runCatching { File(p).delete() }.getOrDefault(false)
        if (ok) MediaScannerConnection.scanFile(ctx, arrayOf(p), null, null)
        return ok
    }

    private fun build(ctx: Context, uri: Uri, sample: Int, orient: Int, info: PhotoInfo,
                      st: WmStyle, device: String, logo: Bitmap?): Pair<Bitmap, IntArray?> {
        val d = decode(ctx, uri, orient, sample, Int.MAX_VALUE)
        var b = d.bmp
        if (!b.isMutable) b = b.copy(Bitmap.Config.ARGB_8888, true)
        val box = Renderer.box(b.width, b.height, st)
        val out = Renderer.render(b, info, st, device, logo)
        if (out !== b) b.recycle()
        return Pair(out, box)
    }

    /**
     * 导入照片的预览（长边不超过 1600px）。
     * 照片本身已带水印（本 App 的标记，或识别到纯色边框）时直接显示原图，避免和当前样式叠成双水印；
     * 否则用当前样式渲染加水印效果。
     */
    fun previewOf(ctx: Context, uri: Uri, st: WmStyle, device: String): Pv {
        val exif = ctx.contentResolver.openInputStream(uri)!!.use { ExifInterface(it) }
        val info = Renderer.readInfo(exif, System.currentTimeMillis())
        val orient = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
        var b = decode(ctx, uri, orient, 1, 1600).bmp
        val mark = exif.getAttribute(ExifInterface.TAG_IMAGE_DESCRIPTION).orEmpty().split("|")
        if ((mark.size == 8 && mark[0] == MARK) || looksFramed(b)) return Pv(b, 1)
        if (!b.isMutable) b = b.copy(Bitmap.Config.ARGB_8888, true)
        val out = Renderer.render(b, info, st, device, Renderer.logo(ctx, st))
        if (out !== b) b.recycle()
        return Pv(out, 0)
    }

    private class Dec(val bmp: Bitmap, val ss: Int, val fullW: Int, val fullH: Int)

    private fun decode(ctx: Context, uri: Uri, orient: Int, sample: Int, maxEdge: Int): Dec {
        val cr = ctx.contentResolver
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, o) }
        var ss = sample
        while ((o.outWidth.toLong() / ss) * (o.outHeight / ss) > 52_000_000L ||
            maxOf(o.outWidth, o.outHeight) / ss > maxEdge) ss *= 2
        val o2 = BitmapFactory.Options().apply {
            inSampleSize = ss; inMutable = true; inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val b = cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, o2) } ?: error("解码失败")
        return Dec(orient(b, orient), ss, o.outWidth, o.outHeight)
    }

    /** 去水印的裁剪方案：结果类型 + 裁剪框 [left, top, w, h]（解码后位图坐标；无法去除时框为 null）。 */
    private fun cropPlan(exif: ExifInterface, orient: Int, dec: Dec): Pair<RemoveResult, IntArray?> {
        val mark = exif.getAttribute(ExifInterface.TAG_IMAGE_DESCRIPTION).orEmpty().split("|")
        val bmp = dec.bmp
        var crop: IntArray? = null
        if (mark.size == 8 && mark[0] == MARK && orient == 1 &&
            mark[1].toIntOrNull() == dec.fullW && mark[2].toIntOrNull() == dec.fullH) {
            val v = mark.subList(3, 7).map { it.toIntOrNull() }
            if (v.any { it == null }) return Pair(RemoveResult.BAKED, null)   // 标记为 none：角标 / 玻璃
            val k = v.map { it!! / dec.ss }
            if (k[0] >= 0 && k[1] >= 0 && k[2] > 0 && k[3] > 0 && k[0] + k[2] <= bmp.width && k[1] + k[3] <= bmp.height)
                crop = intArrayOf(k[0], k[1], k[2], k[3])
        }
        if (crop == null) crop = detectBorder(bmp)
        return if (crop == null) Pair(RemoveResult.NONE, null) else Pair(RemoveResult.OK, crop)
    }

    /** 只在内存里算：去水印后的预览（长边不超过 1600px），不保存。无法去除时 bmp 为原图。 */
    fun removedPreview(ctx: Context, uri: Uri): RemovePreview {
        val exif = ctx.contentResolver.openInputStream(uri)!!.use { ExifInterface(it) }
        val orient = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
        val dec = decode(ctx, uri, orient, 1, 1600)
        val (res, crop) = cropPlan(exif, orient, dec)
        if (crop == null) return RemovePreview(res, dec.bmp)
        val out = Bitmap.createBitmap(dec.bmp, crop[0], crop[1], crop[2], crop[3])
        if (out !== dec.bmp) dec.bmp.recycle()
        return RemovePreview(RemoveResult.OK, out)
    }

    /** 只检测能不能去除水印，不保存。 */
    fun analyze(ctx: Context, uri: Uri): RemoveResult {
        val r = removedPreview(ctx, uri)
        r.bmp.recycle()
        return r.result
    }

    /**
     * 去水印并另存为 Pictures/Watermark/NOWM_xxx.jpg（不动源文件），由「导出」按钮触发。
     * 返回 RemoveResult 的 ordinal：0 = 成功，1 = 水印画在像素上无法去除，2 = 未检测到边框水印。
     * 1) 本 App 新版导出的图带有精确标记：边框条 / 全边框直接按标记裁回原照片；角标 / 玻璃无法还原。
     * 2) 没有标记的图（旧版导出、其他来源）：尝试识别纯色边框并裁掉，识别不到则跳过。
     */
    fun removeWatermark(ctx: Context, uri: Uri, name: String): Int {
        val cr = ctx.contentResolver
        val exif = cr.openInputStream(uri)!!.use { ExifInterface(it) }
        val orient = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)
        val time = Renderer.readInfo(exif, System.currentTimeMillis()).time

        var d: Dec? = null
        for (sample in intArrayOf(1, 2, 4)) {
            try { d = decode(ctx, uri, orient, sample, Int.MAX_VALUE); break }
            catch (e: OutOfMemoryError) { System.gc() }
        }
        val dec = d ?: error("内存不足")
        val bmp = dec.bmp
        val (res, crop) = cropPlan(exif, orient, dec)
        if (crop == null) { bmp.recycle(); return res.ordinal }

        val out = Bitmap.createBitmap(bmp, crop[0], crop[1], crop[2], crop[3])
        if (out !== bmp) bmp.recycle()
        val base = name.substringBeforeLast('.').removePrefix("WM_")
        save(ctx, out, "NOWM_$base.jpg", time, exif, null)
        return RemoveResult.OK.ordinal
    }

    /** 预览用的保守判断：识别到的边框要足够明显（底边 ≥ 4% 高，或有左右边框），避免夜景等暗角被误判成水印。 */
    private fun looksFramed(b: Bitmap): Boolean {
        val c = detectBorder(b) ?: return false
        return c[0] > 0 || b.height - c[1] - c[3] >= b.height * 0.04f
    }

    private fun near(a: Int, b: Int, t: Int = 14): Boolean =
        Math.abs(Color.red(a) - Color.red(b)) <= t && Math.abs(Color.green(a) - Color.green(b)) <= t &&
            Math.abs(Color.blue(a) - Color.blue(b)) <= t

    /** 识别四周纯色边框（含底部文字区），返回 [left, top, width, height]；识别不到返回 null。 */
    private fun detectBorder(b: Bitmap): IntArray? {
        val w = b.width; val h = b.height
        if (w < 64 || h < 64) return null
        val bg = b.getPixel(1, h - 2)
        if (!near(bg, b.getPixel(w - 2, h - 2), 6)) return null
        val row = IntArray(w); val col = IntArray(h)
        fun rowFrac(y: Int): Float {
            b.getPixels(row, 0, w, 0, y, w, 1)
            var n = 0; for (x in 0 until w) if (near(row[x], bg)) n++
            return n.toFloat() / w
        }
        fun colFrac(x: Int): Float {
            b.getPixels(col, 0, 1, x, 0, 1, h)
            var n = 0; for (y in 0 until h) if (near(col[y], bg)) n++
            return n.toFloat() / h
        }
        // 底部：文字行也算边框，阈值放宽
        var bottom = 0
        while (bottom < h * 0.30 && rowFrac(h - 1 - bottom) >= 0.65f) bottom++
        // 左右：纯色
        var left = 0
        while (left < w * 0.15 && colFrac(left) >= 0.98f) left++
        var right = 0
        while (right < w * 0.15 && colFrac(w - 1 - right) >= 0.98f) right++
        val frame = left > 0 && right > 0
        var top = 0
        if (frame) {
            val th = if (colFrac(left / 2) >= 0.98f) 0.40f else 0.98f   // 胶片齿孔会让顶边不够纯
            while (top < h * 0.30 && rowFrac(top) >= th) top++
        }
        if (!frame) { left = 0; right = 0; top = 0 }
        val minEdge = maxOf(2, minOf(w, h) / 100)
        if (bottom < minEdge && !(frame && left >= minEdge)) return null
        val cw = w - left - right; val ch = h - top - bottom
        if (cw < w * 0.5 || ch < h * 0.5) return null
        return intArrayOf(left, top, cw, ch)
    }

    private fun orient(b: Bitmap, o: Int): Bitmap {
        val m = Matrix()
        when (o) {
            ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
            else -> return b
        }
        val r = Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
        if (r !== b) b.recycle()
        return r
    }
}
